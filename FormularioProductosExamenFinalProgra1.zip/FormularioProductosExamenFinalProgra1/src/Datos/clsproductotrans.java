/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author Xofo
 */
public class clsproductotrans {
    ArrayList<clsproducto>pro;
    
    public clsproductotrans(){
        pro=new ArrayList<>();  
    }
    //nos ayuda a cargar la informacion previamente guardada
    public void cargar(){
        cargar();
        try{
            File archivo = new File("producto.txt");
                    if(archivo.exists()){
                        BufferedReader br = new BufferedReader(new FileReader(archivo));
                        String linea = "";  //captura a c/u de las lineas que tiene el archivo
                        while((linea = br.readLine())!= null){
                            StringTokenizer st= new StringTokenizer(linea,","); //ayuda a serparar los atributos
                            int codigo = Integer.parseInt(st.nextToken());
                            String nombre= st.nextToken();
                            String descripcion = st.nextToken();
                            String fechaAdquisicion = st.nextToken();
                            String fechaVencimiento = st.nextToken();
                            double precio = Double.parseDouble(st.nextToken());
                            clsproducto x = new clsproducto(codigo, nombre, descripcion, fechaAdquisicion, fechaVencimiento, precio);
                            adicionar(x);
                            
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Parece, que el archivo no existe. Intente nuevamente.");
                    }
        }catch(Exception e){
        }
    }
    
    public clsproducto obtener(int pos){
        return pro.get(pos);     
    }
    public int tamaño(){
        return pro.size();
    }
    public void adicionar(clsproducto x){
        pro.add(x);
    }
    public void grabar(){
        try{
            PrintWriter pw= new PrintWriter(new FileWriter("producto.txt"));
            for(int i=0; i<tamaño(); i++){
                pw.print(obtener(i).getCodigo()+","+obtener(i).getNombre()+","+obtener(i).getDescripcion()+","+obtener(i).getFAdquisicion()+","+obtener(i).getFVencimiento()+","+obtener(i).getPrecio()+"\r\n");
            }
            pw.close();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Se ha producido un error al grabar el producto, intente nuevamente");
        
        }
    }
}
