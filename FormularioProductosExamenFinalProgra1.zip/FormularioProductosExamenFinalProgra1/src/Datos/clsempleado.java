/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author Xofo
 */

//atributos del empleado

public class clsempleado {
    private int codigoempleado;
    private String apellido;
    private String nombre;
    private String tipoempleado;
    private String contraseña;
    private String estado;

    //constructor donde se inizializan los atributos, hace efecto cada vez que instanciamos a clsempleado
    public clsempleado(int codigoempleado, String apellido, String nombre, String tipoempleado, String contraseña, String estado) {
        this.codigoempleado = codigoempleado;
        this.apellido = apellido;
        this.nombre = nombre;
        this.tipoempleado = tipoempleado;
        this.contraseña = contraseña;
        this.estado = estado;
    }
//encapsulamiento de los atributos
    /**
     * @return the codigoempleado
     */
    public int getCodigoempleado() {
        return codigoempleado;
    }

    /**
     * @param codigoempleado the codigoempleado to set
     */
    public void setCodigoempleado(int codigoempleado) {
        this.codigoempleado = codigoempleado;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the tipoempleado
     */
    public String getTipoempleado() {
        return tipoempleado;
    }

    /**
     * @param tipoempleado the tipoempleado to set
     */
    public void setTipoempleado(String tipoempleado) {
        this.tipoempleado = tipoempleado;
    }

    /**
     * @return the contraseña
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * @param contraseña the contraseña to set
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
}
