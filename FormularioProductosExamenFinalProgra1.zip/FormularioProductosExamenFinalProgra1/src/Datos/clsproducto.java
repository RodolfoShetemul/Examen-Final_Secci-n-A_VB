/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author Xofo
 */
public class clsproducto {
    private int Codigo;
    private String Nombre;
    private String Descripcion;
    private String FAdquisicion;
    private String FVencimiento;
    private double Precio;

    public clsproducto(int Codigo, String Nombre, String Descripcion, String FAdquisicion, String FVencimiento, double Precio) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.FAdquisicion = FAdquisicion;
        this.FVencimiento = FVencimiento;
        this.Precio = Precio;
    }

    /**
     * @return the Codigo
     */
    public int getCodigo() {
        return Codigo;
    }

    /**
     * @param Codigo the Codigo to set
     */
    //donde encapsule los atributos 
    //retorna el valor de setCodigo y así con los demás encapsulados
    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    /**
     * @return the Nombre
     */
    //permite editar el codigo y así con los demás encapsulados
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the Descripcion
     */
    public String getDescripcion() {
        return Descripcion;
    }

    /**
     * @param Descripcion the Descripcion to set
     */
    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    /**
     * @return the FAdquisicion
     */
    public String getFAdquisicion() {
        return FAdquisicion;
    }

    /**
     * @param FAdquisicion the FAdquisicion to set
     */
    public void setFAdquisicion(String FAdquisicion) {
        this.FAdquisicion = FAdquisicion;
    }

    /**
     * @return the FVencimiento
     */
    public String getFVencimiento() {
        return FVencimiento;
    }

    /**
     * @param FVencimiento the FVencimiento to set
     */
    public void setFVencimiento(String FVencimiento) {
        this.FVencimiento = FVencimiento;
    }

    /**
     * @return the Precio
     */
    public double getPrecio() {
        return Precio;
    }

    /**
     * @param Precio the Precio to set
     */
    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    
    
}
