/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;
//se crean los movimientos y transacciones del empleado
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author Xofo
 */
public class clsempleadotransacciones {
    ArrayList<clsempleado> empleado;
//se crea un constructor para inicializar a clsempleado
    public clsempleadotransacciones() {
        empleado = new ArrayList<clsempleado>();
        cargar();
    }
    
    private void cargar(){
        try{
            File archivo = new File("empleados.txt");
            if(archivo.exists()){
                BufferedReader br= new BufferedReader (new FileReader(archivo));
                String linea="";
                while((linea=br.readLine())!=null){
                    StringTokenizer st= new StringTokenizer(linea,",");
                    int codigoempleado= Integer.parseInt(st.nextToken());
                    String apellido= st.nextToken();
                    String nombre= st.nextToken();
                    String tipoempleado= st.nextToken();
                    String contraseña= st.nextToken();
                    String estado= st.nextToken();
                    
                    clsempleado x= new clsempleado(codigoempleado, apellido, nombre, tipoempleado, contraseña, estado);
                    adicionar(x);
                }
                br.close();
            }else{
                JOptionPane.showMessageDialog(null, "Error el archivo empleado.txt no existe");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Se ocurrio un error al cargar los registros de empleados");
        }
    }
    
    
    
    //metodos para manipular la plantilla
    public clsempleado obtener(int pos){
        return empleado.get(pos);    
    }
    
    public int tamaño(){
        return empleado.size();    
    }
    
    public void adicionar(clsempleado x){
        empleado.add(x);    
    }
    //imprime los registrso en un block de notas
    public void grabar(){
        try{
            PrintWriter pw= new PrintWriter(new FileWriter("empleados.txt"));
            for(int i=0; i<tamaño(); i++){
                pw.print(obtener(i).getCodigoempleado()+","+obtener(i).getApellido()+","+obtener(i).getNombre()+","+obtener(i).getTipoempleado()+","+obtener(i).getContraseña()+","+obtener(i).getEstado()+"\r\n");
             }
            pw.close();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al grabar los datos" +e);
        }    
    }
}
