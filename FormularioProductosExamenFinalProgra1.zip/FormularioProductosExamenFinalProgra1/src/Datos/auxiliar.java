/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Presentacion.FRMPrincipal;
import Presentacion.FRMProducto;
import java.awt.Panel;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Xofo
 */
public class auxiliar {

    public static void validarnumeros(KeyEvent tecla, String texto, int cantidad) {
        char t = tecla.getKeyChar();
        if (Character.isDigit(t) && texto.length() < cantidad) {

        } else {
            tecla.consume();
        }
    }

    public static void validarDecimales(KeyEvent tecla) {
        char t = tecla.getKeyChar();
        if (Character.isDigit(t) || t == '.') {
        } else {
            tecla.consume();
        }
    }

    public static void verPantalla(JDesktopPane escritorio, JInternalFrame frame) {
        if (frame.isShowing() == false) {
            FRMPrincipal.jdpescritorio.add(frame);
            frame.show();
            frame.setLocation((escritorio.getWidth() - frame.getWidth()) / 2, (escritorio.getHeight() - frame.getHeight()) / 2);

        }
        //le doy formato a la tabla, debido a que unos campos guardan más información que otros
    public static void formatoTabla(JTable tabla, int[] tamaño) {
        for (int i = 0; i < tamaño.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(tamaño[i]);
        }
    }

    public static String GenerarCodigoProducto(int Cantidad, int Tamaño) {
        clsproductotrans pro = new clsproductotrans();
        boolean salir = false;
        String codigo = "";
        int talla = 0;
        int existe = 0;
        while (salir == false) {
            codigo = "" + (int) (Math.random() * Cantidad);
            talla = codigo.length();
            if (talla < Tamaño) {
                for (int i = 0; i < (Tamaño - talla); i++) {
                    codigo += "0";
                }
            }
            existe = 0;
            for (int p = 0; p < pro.tamaño(); p++) {
                if (Integer.parseInt(codigo) == pro.obtener(p).getCodigo()) {
                    existe++;
                    break;
                }
            }
            if (existe < 1) {
                salir = true;
            }
        }
        return codigo;

    }

    public static String Nombre(JTextField cajaTexto) {
        String texto = cajaTexto.getText();
        if (texto.equals("")) {
            while (texto.equals("")) {
                texto = JOptionPane.showInputDialog(null, "Ingrese el nombre del producto, por favor.");
                if (texto == null) {
                    texto = "";
                }
            }
        }
        return texto;
    }

    public static String Descripcion(JTextField cajaDescripcion) {
        String descripcion = cajaDescripcion.getText();
        if (descripcion.equals("")) {
            while (descripcion.equals("")) {
                descripcion = JOptionPane.showInputDialog(null, "Ingrese una descripcion del producto, por favor.");
                if (descripcion == null) {
                    descripcion = "";
                }
            }
        }
        return descripcion;
    }

    public static double precio(JTextField cajaTexto) {
        double pre = 0;
        String preStr = cajaTexto.getText();
        boolean salir = false;
        while (salir == false) {
            try {
                pre = Double.parseDouble(preStr);
                salir = true;
            } catch (Exception e) {
                salir = false;
                preStr = JOptionPane.showInputDialog(null, "Ingrese correctamente el precio, por favor");
            }
        }
        return pre;
    }

    public static String fechaVencimiento(JTextField dia, JTextField mes, JTextField año) {
        String ingreso = dia.getText() + "/" + mes.getText() + "/" + año.getText();
        Date fechasistema = new Date();

        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyy");
        Date ingresoCon = null;
        String ingresoRet = "";
        boolean salir = false;
        while (salir == false) {
            try {
                ingresoCon = formato.parse(ingreso);
                ingresoRet = formato.format(ingresoCon);
                /*if (ingreso.equals(ingresoRet)) {
                    if(fechasistema.after(ingresoCon)){
                        ingreso = JOptionPane.showInputDialog(null, "Solo se permiten fechas mayores al día de hoy.");

                    } else {
                        salir = true;
                    }
                    }else{
                                 ingreso = JOptionPane.showInputDialog(null, "La fecha ingresada no es correcta, intente nuevamente");
                                 }
            } catch (Exception e) {
                ingreso = JOptionPane.showInputDialog(null, "La fecha ingresada no es correcta");
            }*/
        }
        return ingreso;
    }
        public static String fechaAdquisicion(JTextField dia, JTextField mes, JTextField año) throws ParseException {
        String ingreso = dia.getText() + "/" + mes.getText() + "/" + año.getText();
        Date fechasistema = new Date();

        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyy");
        Date ingresoCon = null;
        String ingresoRet = "";
        boolean salir = false;
        while (salir == false) {
            try {
                ingresoCon = formato.parse(ingreso);
                ingresoRet = formato.format(ingresoCon);
                /*if (ingreso.equals(ingresoRet)) {
                    if(fechasistema.after(ingresoCon)){
                        ingreso = JOptionPane.showInputDialog(null, "Solo se permiten fechas mayores al día de hoy.");

                    } else {
                        salir = true;
                    }
                    }else{
                        ingreso = JOptionPane.showInputDialog(null, "La fecha ingresada no es correcta, intente nuevamente");
                                 }
            } catch (Exception e) {
                ingreso = JOptionPane.showInputDialog(null, "La fecha ingresada no es correcta");
            }*/
        }
        return ingreso;
    }
}

/*public static void verPantalla(Panel jdpescritorio, FRMProducto producto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}*/
